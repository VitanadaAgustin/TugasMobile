package com.example.restapi

interface ItemClikHandler {
    fun onSpinnerClik(dataResp: PostRespon, action: String)
}